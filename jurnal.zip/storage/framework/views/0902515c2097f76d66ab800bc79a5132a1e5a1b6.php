<div class="row">
    <h1><?php echo e($data->fullname); ?></h1>
</div><?php /**PATH /run/media/mattsoleh/DATA/lara/jurnal/resources/views/dash-admin/detiluser.blade.php ENDPATH**/ ?>