<nav class="navbar navbar-expand-lg " color-on-scroll="500">
    <div class="container-fluid">
        <a class="navbar-brand" href="#" style="text-transform: capitalize;">
            <?php echo e($page); ?>

        </a>
        <button href="" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-bar burger-lines"></span>
        <span class="navbar-toggler-bar burger-lines"></span>
        <span class="navbar-toggler-bar burger-lines"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <ul class="nav navbar-nav mr-auto">
                <li class="nav-item">
                    <a href="#" class="nav-link" data-toggle="dropdown">
                        
                        <span class="d-lg-none">
                            <?php if($page): ?>
                            <?php echo e($page); ?>

                            <?php else: ?>
                            Jurnal
                            <?php endif; ?>
                        </span>
                    </a>
                </li>
                
            </ul>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <?php if(file_exists(public_path('/img/faces/'.Auth::user()->nip.'.jpg'))): ?>
                            <img src="<?php echo e(asset('/img/faces/'.Auth::user()->nip.'.jpg')); ?>" alt="Avatar" class="img navbar-face" >
                        <?php else: ?>
                            <img src="<?php echo e(asset('/img/avatar-1.png')); ?>" alt="Avatar" class="img navbar-face" >
                        <?php endif; ?>
                        &nbsp;
                        <span class="no-icon"><?php echo e(Auth::user()->fullname); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/logout">
                        <i class="nc-icon nc-button-power"></i>
                        &nbsp;
                        <span class="no-icon">Keluar</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH /home/mattsoleh/Projects/lara/jurnal/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>