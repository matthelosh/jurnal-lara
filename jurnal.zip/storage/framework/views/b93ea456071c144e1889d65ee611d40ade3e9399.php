<?php $__env->startSection('content'); ?>
	<?php if(Auth::user()->level == 'guru'): ?>
		<?php if($page): ?>
			<?php switch($page):
				case ('dashboard'): ?>
					<?php echo $__env->make('layouts.defaultcontent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php break; ?>
			<?php endswitch; ?>
		<?php endif; ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/mattsoleh/DATA/lara/jurnal/resources/views/dash-guru/index.blade.php ENDPATH**/ ?>