<?php $__env->startSection('content'); ?>
	<?php if(Auth::user()->level == 'admin'): ?>
		<?php if($page): ?>
			<?php switch($page):
				case ('dashboard'): ?>
					<?php echo $__env->make('layouts.defaultcontent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php break; ?>
				<?php case ('users'): ?>
					<?php echo $__env->make('dash-admin.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php break; ?>
				<?php case ('detiluser'): ?>
				    <?php echo $__env->make('dash-admin.detiluser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php break; ?>
				<?php case ('siswa'): ?>
					<?php echo $__env->make('dash-admin.siswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php break; ?>
				<?php case ('rombel'): ?>
					<?php echo $__env->make('dash-admin.rombel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php break; ?>
				<?php case ('mapel'): ?>
					<?php echo $__env->make('dash-admin.mapel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php break; ?>
				<?php case ('jadwal'): ?>
					<?php echo $__env->make('dash-admin.jadwal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php break; ?>
				<?php case ('sekolah'): ?>
					<?php echo $__env->make('dash-admin.sekolah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php break; ?>
				<?php case ('pengaturan'): ?>
					<?php echo $__env->make('dash-admin.pengaturan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php break; ?>
			<?php endswitch; ?>
		<?php endif; ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mattsoleh/Projects/lara/jurnal/resources/views/dash-admin/index.blade.php ENDPATH**/ ?>