<?php if(Auth::user()->level == 'admin'): ?>
   <div class="row">
       <div class="col-sm-12">
           <div class="card">
               <div class="card-header">
                <?php ($tgl = date('d M Y')); ?>
                   <h5 class="card-title">Jadwal Pelajaran Hari <?php echo e($hari); ?>, <?php echo e($tgl); ?></h5>
                   <button class="btn btn-danger float-right" id="btn-tutup-jadwal">Tutup Jadwal</button>
                
               </div>
               <div class="card-body">
                   <div class="row">
                       <div class="container">
                            <div class="alert bg-danger center-text alert-logabsen" style="display:none;">
                                    <?php if($hari != 'Sabtu' || $hari != 'Minggu'): ?>
                                        <div class="alert bg-danger text-center">
                                            <h3>Jadwal hari <?php echo e($hari); ?>, belum diaktifkan.</h3>
                                            <button class="btn btn-warning btn-lg" id="btn-aktifkan-jadwal">Aktifkan Jadwal</button>
                                        </div>
                                    <?php else: ?>
                                        <div class="alert bg-warning d-flex">
                                            <h3>Hari ini Libur</h3>    
                                        </div>    
                                    <?php endif; ?>
                                </div>
                       </div>
                   </div>
                   
                        <div class="table-responsive">
                                <table class="table table-sm" id="table-log-absen" width="100%">
                                    <thead>
                                        <tr>
                                            <th>Kelas</th>
                                            <th>Mapel</th>
                                            <th>Guru</th>
                                            <th>Jam Ke</th>
                                            <th>Jml Siswa</th>
                                            <th>H</th>
                                            <th>I</th>
                                            <th>S</th>
                                            <th>A</th>
                                            <th>T</th>
                                            <th>Jurnal/Materi</th>
                                            <th>Keterangan</th>
                                            <th>Status</th>
                                            <th>Opsi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>   
                        </div>
                    
               </div>
           </div>
       </div>
   </div>
<?php elseif(Auth::user()->level == 'guru'): ?>
    <div class="row">
        <div class="container">
            <h3 class="text-center">
                Jadwal Anda hari ini:
            </h3>
        
            <div class="d-flex justify-content-around flex-md-row flex-wrap">
                <?php if($jadwals->count() < 1): ?>
                    <div class="alert bg-danger text-center">
                        <h3>Tidak ada jadwal mengajar :)</h3>
                    </div>
                <?php else: ?>
                    <div class="card-deck">
                        <?php $__currentLoopData = $jadwals ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card <?php echo e(($jadwal->ket == 'jamkos') ? 'bg-danger border-success' : 'bg-success border-danger'); ?> " >
                                <div class="card-body text-white">
                                    <h5><?php echo e($jadwal->rombels->nama_rombel); ?></h5>
                                    <h5><?php echo e($jadwal->jamke); ?></h5>
                                    <h5><?php echo e($jadwal->mapels->nama_mapel); ?></h5>
                                    <a href="/dashboard/do-absen/<?php echo e($jadwal->kode_absen); ?>" class="card-link stretched-link"></a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php elseif(Auth::user()->level == 'staf'): ?>
    <div class="row">
        <h3>Jurnal Staf</h3>
    </div>
<?php else: ?>
    <div class="row">
        <h3>Guru Piket</h3>
    </div>
<?php endif; ?><?php /**PATH /home/mattsoleh/Projects/lara/jurnal/resources/views/layouts/defaultcontent.blade.php ENDPATH**/ ?>